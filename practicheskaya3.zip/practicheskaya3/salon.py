
import datetime
import json
import os


class User:
    def __init__(self, username, password, role, history=None):
        self.username = username
        self.password = password
        self.role = role
        self.history = history if history else []

    def to_dict(self):
        return {
            'username': self.username,
            'password': self.password,
            'role': self.role,
            'history': self.history
        }

    @classmethod
    def from_dict(cls, data):
        return cls(data['username'], data['password'], data['role'], data['history'])


class Service:
    def __init__(self, name, price, duration, added_at=None):
        self.name = name
        self.price = price
        self.duration = duration
        self.added_at = added_at if added_at else datetime.date.today()

    def __str__(self):
        return f"{self.name} - Цена: {self.price} руб., Длительность: {self.duration} мин., Добавлено: {self.added_at}"

    def to_dict(self):
        return {
            'name': self.name,
            'price': self.price,
            'duration': self.duration,
            'added_at': str(self.added_at) 
        }

    @classmethod
    def from_dict(cls, data):
        return cls(data['name'], data['price'], data['duration'], datetime.datetime.strptime(data['added_at'], '%Y-%m-%d').date())


class Cart:
    def __init__(self):
        self.items = []

    def add_item(self, service):
        self.items.append(service)

    def get_total(self):
        return sum(item.price for item in self.items)

    def clear(self):
        self.items = []

    def __str__(self):
        if not self.items:
            return "Корзина пуста"
        return "\n".join(str(item) for item in self.items)


class Client:
    def __init__(self, name, services, total_cost, visit_date, appointment_time):
        self.name = name
        self.services = services
        self.total_cost = total_cost
        self.visit_date = visit_date
        self.appointment_time = appointment_time

    def __str__(self):
        return f"Имя: {self.name}, Услуги: {', '.join(self.services)}, Стоимость: {self.total_cost} руб., Дата визита: {self.visit_date}, Время записи: {self.appointment_time}"

    def to_dict(self):
        return {
            'name': self.name,
            'services': self.services,
            'total_cost': self.total_cost,
            'visit_date': self.visit_date,
            'appointment_time': self.appointment_time
        }

    @classmethod
    def from_dict(cls, data):
        return cls(data['name'], data['services'], data['total_cost'], data['visit_date'], data['appointment_time'])



class DataManager:
    SERVICES_FILE = 'services.json'
    CLIENTS_FILE = 'clients.json'
    USERS_FILE = 'users.json'

    @staticmethod
    def load_data(filename, from_dict_method):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return [from_dict_method(item) for item in data]
        except FileNotFoundError:
            return []
        except Exception as e:
            print(f"Error loading data from {filename}: {e}")
            return []

    @staticmethod
    def save_data(filename, data):
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump([item.to_dict() for item in data], f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving data to {filename}: {e}")

class AuthenticationService: 
    def authenticate(self, username, password, users):
        for user in users:
            if user.username == username and user.password == password:
                return user
        return None

    def create_user(self, username, password, role, users):
        if any(user.username == username for user in users):
            return None  
        new_user = User(username, password, role)
        users.append(new_user)
        DataManager.save_data(DataManager.USERS_FILE, users)  
        return new_user



class ServiceManager:  
    def add_service(self, services, name, price, duration):
        new_service = Service(name, price, duration)
        services.append(new_service)
        DataManager.save_data(DataManager.SERVICES_FILE, services)
        print("Услуга добавлена.")

    def delete_service(self, services, name):
        for i, service in enumerate(services):
            if service.name == name:
                del services[i]
                DataManager.save_data(DataManager.SERVICES_FILE, services)
                print(f"Услуга '{name}' удалена.")
                return
        print(f"Услуга '{name}' не найдена.")

    def edit_service(self, services, name, new_price=None, new_duration=None):
        for service in services:
            if service.name == name:
                if new_price:
                    service.price = new_price
                if new_duration:
                    service.duration = new_duration
                DataManager.save_data(DataManager.SERVICES_FILE, services)
                print(f"Услуга '{name}' изменена.")
                return
        print(f"Услуга '{name}' не найдена.")

    def display_services(self, services):
        if not services:
            print("Список услуг пуст.")
            return
        print("\nДоступные услуги:")
        for service in services:
            print(service)

    def sort_services(self, services, key, reverse=False):
        return sorted(services, key=key, reverse=reverse)

    def filter_services(self, services, key, value):
        return list(filter(lambda service: key(service) == value, services))


class ClientManager: 
    def checkout(self, user, cart, services, clients):
        if not cart.items:
            print("Корзина пуста.")
            return

        total_cost = cart.get_total()
        name = input("Введите ваше имя: ")
        visit_date = input("Введите дату визита (YYYY-MM-DD): ")
        appointment_time = input("Введите желаемое время (HH:MM): ")
        client = Client(name, [item.name for item in cart.items], total_cost, visit_date, appointment_time)
        clients.append(client)
        DataManager.save_data(DataManager.CLIENTS_FILE, clients)
        cart.clear()
        print(f"Заказ оформлен успешно! Общая стоимость: {total_cost} руб.")

    def display_clients(self, clients):
        if not clients:
            print("Список клиентов пуст.")
            return
        print("\nСписок клиентов:")
        for client in clients:
            print(client)




def user_menu(user, services, clients, client_manager, service_manager): 
    cart = Cart()
    while True:
        print("\nМеню пользователя:")
        print("1. Просмотреть услуги")
        print("2. Запись на услугу")
        print("3. Просмотреть корзину")
        print("4. Оформить заказ")
        print("5. Выйти")

        choice = input("Выберите действие: ")
        try:
            choice = int(choice)
            if choice == 1:
                service_manager.display_services(services)
            elif choice == 2:
                service_manager.display_services(services) 
                try:
                    service_num = int(input("Выберите номер услуги: ")) - 1
                    if 0 <= service_num < len(services):
                        cart.add_item(services[service_num])
                        print(f"Услуга '{services[service_num].name}' добавлена в корзину.")
                    else:
                        print("Неверный номер услуги.")
                except ValueError:
                    print("Неверный ввод. Пожалуйста, введите номер услуги числом.")
            elif choice == 3:
                print(cart)
                print(f"Общая стоимость: {cart.get_total()} руб.")
            elif choice == 4:
                client_manager.checkout(user, cart, services, clients)
            elif choice == 5:
                break
            else:
                print("Неверный выбор.")
        except ValueError:
            print("Неверный ввод.")

def admin_menu(user, services, clients, service_manager, client_manager):
    while True:
        print("\nМеню администратора:")
        print("1. Просмотреть услуги")
        print("2. Добавить услугу")
        print("3. Удалить услугу")
        print("4. Редактировать услугу")
        print("5. Фильтровать услуги")
        print("6. Сортировать услуги")
        print("7. Просмотреть список клиентов")
        print("8. Выйти")

        choice = input("Выберите действие: ")
        try:
            choice = int(choice)
            if choice == 1:
                service_manager.display_services(services)
            elif choice == 2:
                name = input("Название услуги: ")
                price = int(input("Цена: "))
                duration = int(input("Длительность: "))
                service_manager.add_service(services, name, price, duration)
            elif choice == 3:
                name = input("Название услуги для удаления: ")
                service_manager.delete_service(services, name)
            elif choice == 4:
                name = input("Название услуги для редактирования: ")
                new_price = input("Новая цена (пустое поле для пропуска): ")
                new_duration = input("Новая длительность (пустое поле для пропуска): ")
                service_manager.edit_service(services, name, int(new_price) if new_price else None, int(new_duration) if new_duration else None)

            elif choice == 5:
                filter_key = input("Фильтр по (price, duration, name, added_at): ")
                filter_value = input("Значение фильтра: ")
                try:
                    if filter_key == "price" or filter_key == "duration":
                        filtered = service_manager.filter_services(services, lambda s: getattr(s, filter_key), int(filter_value))
                    elif filter_key == "name" or filter_key == "added_at":
                        filtered = service_manager.filter_services(services, lambda s: getattr(s, filter_key), filter_value)
                    else:
                        raise ValueError
                    service_manager.display_services(filtered)
                except ValueError:
                    print("Неверный ключ или значение для фильтрации")

            elif choice == 6:
                sort_key = input("Сортировать по (price, duration, name, added_at): ")
                reverse = input("Обратный порядок (yes/no): ").lower() == "yes"
                try:
                    if sort_key == "price" or sort_key == "duration":
                        sorted_services = service_manager.sort_services(services, lambda s: getattr(s, sort_key), reverse)
                    elif sort_key == "name" or sort_key == "added_at":
                        sorted_services = service_manager.sort_services(services, lambda s: getattr(s, sort_key), reverse)
                    else:
                        raise ValueError
                    service_manager.display_services(sorted_services)
                except ValueError:
                    print("Неверный ключ для сортировки")

            elif choice == 7:
                client_manager.display_clients(clients)
            elif choice == 8:
                break
            else:
                print("Неверный выбор.")
        except ValueError:
            print("Неверный ввод.")


def main():
    users = DataManager.load_data(DataManager.USERS_FILE, User.from_dict)
    services = DataManager.load_data(DataManager.SERVICES_FILE, Service.from_dict)
    clients = DataManager.load_data(DataManager.CLIENTS_FILE, Client.from_dict)

    auth_service = AuthenticationService()
    service_manager = ServiceManager()
    client_manager = ClientManager()

    while True:
        username = input("Логин: ")
        password = input("Пароль: ")
        user = auth_service.authenticate(username, password, users)
        if user:
            if user.role == 'admin':
                admin_menu(user, services, clients, service_manager, client_manager)
            elif user.role == 'user':
                user_menu(user, services, clients, client_manager, service_manager) 
            print("Вы вышли из системы.")
        else:
            print("Неверный логин или пароль.")


if __name__ == "__main__":
    main()